# PCCP-Bench 0.1.3 — 怎么用、怎么验

## 一条命令先确认它能跑

```
python -c "import sys; sys.path.insert(0,'dataset'); import adapter_reference as a; print(a.engine_source())"
# 应打印：judges (vendored in this bundle)
```

然后进入 `dataset/`：

```
python bench.py --submit adapter_reference.py     # 参考裁判：public 0.9688 / masked 0.9688 / tag 1.0
python bench.py --commit-check                    # 10 条隐藏题承诺（无隐藏题时 PASS）
python bench.py --verify <score.json>             # 复算一份成绩（不是 zip；第一版写错过）
python bench.py --template                        # 给要被评测的人看的适配器模板
```

跑别人的适配器：`python bench.py --submit your_adapter.py --team you`。

## 裁判从哪来（0.1.0 的致命缺陷就在这）

包内有 `judges/`（`judge_pccp.py` + `base.py` + `__init__.py`），是 lgd-engine 的最小闭包，原样复制。
`adapter_reference.py` 按 `包内 judges → LGD_ENGINE_ROOT → 已安装 lgd_engine` 三级加载，打印 `engine_source()`
告诉你这次用的是哪一份。

v0.1.0 只搬了 `judge_pccp.py`，而它写着 `from .base import ...`，`base.py` 没随包发布 ——
于是在别人机器上第一行就 `ImportError`。**这就是为什么要重发 0.1.1。**

## 复算冻结根

```
python -c "import hashlib,json;m=json.load(open('MANIFEST.json'));print(all(hashlib.sha256(open(f['archive_path'],'rb').read()).hexdigest()==f['sha256'] for f in m['files']))"
```

根：`0f1e697b60ea39face648f86a3268006a410b3ec6e93c5adc8e3165e61a1c60f`
规则：叶子取文件 sha256 摘要的**字节**、按 `path` 排序、成对 `sha256(a+b)`、奇数节点与自身配对。
（写成 `sha256(path + NUL + 摘要)` 也能算出一个根，但那是错的：会得到 `662ba5a7…`，与冻结值不符。）

## 版本关系

- concept DOI：`10.5281/zenodo.24550266`（所有版本挂在它下面）
- `0.1.0`（`10.5281/zenodo.24550267`）：包内缺裁判依赖，已被取代
- `0.1.3`：本文这一版
