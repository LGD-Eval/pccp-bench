# 许可证状态：已定（0.1.3）

| 对象 | 许可 |
|---|---|
| 数据集正文（cases_public.json、case_index.csv、DATASET_CARD.md、evidence/ 日志与成绩） | **CC BY 4.0** |
| 代码（bench.py、bench_template.py、adapter_reference.py、make_evidence.py、judges/ 三件） | **Apache-2.0** |
| 隐藏题承诺（hidden_commitment.json，仅哈希） | CC BY 4.0 |

Zenodo 记录的 license 字段写的是 `cc-by-4.0`（数据集口径）；代码另注 Apache-2.0。

## 0.1.0 里为什么写着"未选定"

v0.1.0 打包时许可尚未确定，那份文件留在了包里，于是出现"包外已定、包内说未定"的矛盾。
0.1.0 已发布，字节不可改；0.1.1 起本文件与记录一致（0.1.3 延续同一口径）。
