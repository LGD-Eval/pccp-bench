# judges/ — vendored judge closure

这三个文件来自 lgd-engine 的 `lgd_engine/judges/`（`__init__.py`、`base.py`、`judge_pccp.py`），
原样复制，只为了让人解包就能跑，不必先装引擎。

为什么不止一个文件：`judge_pccp.py` 里写着 `from .base import DomainJudge, JudgeVerdict, Reason, Evidence, is_unusable, misused`。只搬 `judge_pccp.py` 会得到一个"看起来自包含"的包，实际在别人机器上第一行就 `ImportError: attempted relative import with no known parent package`。

`base.py` 只依赖标准库（dataclasses / typing），所以这个闭包是完整的。
许可：见包根 `LICENSE_STATUS.md`（数据 CC BY 4.0；代码 Apache-2.0）。
