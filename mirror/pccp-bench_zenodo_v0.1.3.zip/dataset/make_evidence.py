# -*- utf-8 -*-
"""把"我们说的分数"变成"别人能看到的原始输出"。

外部 AI 的第四条质疑一针见血：README 里那几个数（0.9688 / 0.875 / 背题者 1.0→0.094）
读起来像结论，但包里没有任何一份可以拿来对照的原始输出。于是它只能当作自述。
本脚本把参考实现、背题者、commit-check 三次真实运行的完整输出落到 evidence/ 里，
连同复现命令一起发布，读者不必相信我们的话，只要对着日志重跑。

日志含时间戳会破坏"逐字节可复算"吗？不会——日志本身是叶子，冻结根覆盖它；
它会随每次重跑变旧，所以发布包里固定的是"发布时刻的这一次运行"。
"""
import hashlib, json, os, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

BENCH = Path(__file__).resolve().parent
EV = BENCH / "evidence"
EV.mkdir(exist_ok=True)


def run(args):
    p = subprocess.run([sys.executable] + args, cwd=str(BENCH), capture_output=True, text=True,
                       encoding="utf-8", timeout=600)
    return p.returncode, (p.stdout or "") + (("\n[stderr]\n" + p.stderr) if p.stderr.strip() else "")


CASES = {
    "score_reference.log": ["bench.py", "--submit", "adapter_reference.py", "--team", "reference(ours)"],
    "score_memoriser.log": ["bench.py", "--submit", "adapter_memoriser_for_test.py", "--team", "memoriser(test-only)"],
    "commit_check.log": ["bench.py", "--commit-check"],
}

env_line = (f"# python {platform.python_version()} | {platform.system()} | "
            f"run at {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}\n")
for name, args in CASES.items():
    rc, out = run(args)
    (EV / name).write_text(env_line + "# command: python " + " ".join(args) + f"\n# exit: {rc}\n\n" + out,
                           encoding="utf-8")
    print(name, "exit", rc, "|", out.strip().splitlines()[0][:110] if out.strip() else "")

# 分数文件一并带走：日志说"跑出这个数"，score json 说"这个数由哪些逐题行算出"
out_dir = BENCH / "out"
keep = []
for f in sorted(out_dir.glob("score_*.json")):
    if any(t in f.name for t in ("reference", "memoriser")):
        keep.append(f)
scoredir = EV / "scores"
scoredir.mkdir(exist_ok=True)
for f in keep:
    (scoredir / f.name).write_bytes(f.read_bytes())

index = {"generated_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
         "logs": {k: hashlib.sha256((EV / k).read_bytes()).hexdigest() for k in CASES},
         "scores": {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(scoredir.glob("*.json"))},
         "how_to": "cd dataset && python bench.py --verify evidence/scores/<file>.json"}
(EV / "INDEX.json").write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")

(EV / "README.md").write_text(
    "# evidence/ — 我们说的数，对应的原始输出\n\n"
    "包里每个分数都应该能追到一次真实运行。这里放的就是那几次运行：\n\n"
    "| 文件 | 是什么 | 怎么复现 |\n|---|---|---|\n"
    "| `score_reference.log` | 参考裁判一次完整运行（public 0.9688 / masked 0.9688 / tag 1.0） | `python bench.py --submit adapter_reference.py --team reference` |\n"
    "| `score_memoriser.log` | 背题者（直接读公开答案表）同一次运行（public 1.0 → masked 0.094、tag 0.031） | `python bench.py --submit adapter_memoriser_for_test.py` |\n"
    "| `commit_check.log` | 10 条隐藏题承诺的核对输出 | `python bench.py --commit-check` |\n"
    "| `scores/*.json` | 上面两次运行落下的成绩文件（逐题行 + 摘要） | `python bench.py --verify scores/<file>` |\n\n"
    "两个数要一起看：**参考 1.0→1.0，背题者 1.0→0.094**。masked 列不是难度分，是泄漏探针 ——\n"
    "它低，说明这个判定器在靠编号记答案；它高，才说明它读的是事实。\n\n"
    "`INDEX.json` 给每份日志与成绩文件的 sha256，改一个字节就会和这里对不上。\n\n"
    "这些日志是**发布时刻的那一次运行**，不随你重跑而更新；你重跑得到的输出应当与它一致（时间戳行除外）。\n",
    encoding="utf-8")
print("evidence 完成：", sorted(p.name for p in EV.rglob("*") if p.is_file()))
