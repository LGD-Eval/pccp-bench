"""Reference adapter: our own judge, put on the stand like anyone else's.

Two outputs are required, not one:
  verdict -- go / reject / hold
  tag     -- why, in the bench's own six-word vocabulary

Self-contained on purpose (fixed in v0.1.1)
-------------------------------------------
v0.1.0 hard-coded ENGINE_ROOT to the author's own disk (`D:\\Workbuddy\\05-工具\\...\\lgd-engine`).
On that machine the reference run scored 0.9688 and looked correct; anywhere else it died with
`ModuleNotFoundError: No module named 'lgd_engine'`. A package that only runs where it was built is
not a reproducible package, it is a screenshot. See `judges/README.md` for the second defect that
showed up only after the path was fixed.

Load order, first hit wins:
  1. `judges/` shipped inside this bundle (vendored closure: judge_pccp + base);
  2. `LGD_ENGINE_ROOT` from the environment;
  3. an installed `lgd_engine` package.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))          # 让 `import judges` 命中包内这份

_JUDGE_FROM = "judges (vendored in this bundle)"
try:
    from judges.judge_pccp import JudgePccpScope  # noqa: E402
except ModuleNotFoundError:
    root = os.environ.get("LGD_ENGINE_ROOT")
    if root and Path(root).is_dir():
        sys.path.insert(0, root)
        try:
            from lgd_engine.judges.judge_pccp import JudgePccpScope  # noqa: E402
            _JUDGE_FROM = "lgd_engine @ LGD_ENGINE_ROOT"
        except ModuleNotFoundError:
            _JUDGE_FROM = ""
    else:
        try:
            from lgd_engine.judges.judge_pccp import JudgePccpScope  # noqa: E402
            _JUDGE_FROM = "lgd_engine (installed)"
        except ModuleNotFoundError:
            _JUDGE_FROM = ""
    if not _JUDGE_FROM:
        raise SystemExit(
            "找不到裁判：本包内没有 judges/judge_pccp.py，也没设 LGD_ENGINE_ROOT，环境里也没装 lgd_engine。"
            "这是打包问题，不是用法问题。")

_JUDGE = JudgePccpScope()

RULE_TO_TAG = [
    ("P-CRIT-03", "acceptance_not_met"),
    ("P-CRIT-02", "intended_use_change"),
    ("P-MAJ-01", "outside_scope"),
    ("L2-EVIDENCED", "evidence_missing"),
    ("P-MAJ-10", "unclassifiable"),
]


def _tag(verdict: str, reasons: list) -> str:
    fired = [str(r.get("rule", "")) if hasattr(r, "get") else str(r) for r in reasons]
    for prefix, tag in RULE_TO_TAG:
        if any(f.startswith(prefix) for f in fired):
            return tag
    if verdict == "go":
        return "ok_covered"
    # A non-go verdict with no rule we can name is a record this judge could not
    # place. Do not invent a reason for it.
    return "unclassifiable"


def evaluate(ctx):
    res = _JUDGE.evaluate(dict(ctx))
    verdict = res.get("verdict")
    return {"verdict": verdict, "tag": _tag(verdict, res.get("reasons", [])),
            "reasons": res.get("reasons", [])}


def engine_source() -> str:
    """Where the judge came from -- so a run can say what it judged with."""
    return _JUDGE_FROM
