# -*- utf-8 -*-
"""把 README / 数据卡里的分数与"这一版实测输出"对齐。

发现的问题（0.1.1 发布后才暴露）：文档里的表写着"参考实现 public 1.0、hidden 1.0、
背题者 masked 0.094"，而同一份代码今天跑出来是 0.9688 / 0.9 / 0.125。
差在哪儿不是重点，**文档在报一个它没有证据支持的数**才是重点。
本脚本把两张表改成 evidence/ 里那两次运行的真实值，并把旧值的来历写明，
让读者能看出哪个数可追、哪个数只是旧稿。
"""
import json
from pathlib import Path

B = Path(__file__).resolve().parent
EO = B / "evidence" / "scores"


def load(prefix):
    f = sorted(EO.glob(prefix + "*.json"))[0]
    return json.loads(f.read_text(encoding="utf-8"))


ref, mem = load("score_reference"), load("score_memoriser")
rs, ms = ref["score"], mem["score"]
bl = ref["baseline_always_go"]
rv, mv = rs["public"], ms["public"]


def f4(x):
    return f"{x:g}" if isinstance(x, (int, float)) else str(x)


readme = (B / "README.md").read_text(encoding="utf-8")
old_table_start = readme.index("| 行 | public 结论 |")
old_table_end = readme.index("## 对手有没有台子")
new_block = (
    "| 行 | public 结论 | masked 结论 | hidden 结论 | public 理由 | masked 理由 | 落差 |\n"
    "|---|---|---|---|---|---|---|\n"
    f"| 参考实现（我们自己的判定器） | {rv['exact_rate']} | {rs['masked']['exact_rate']} "
    f"| {rs['hidden']['exact_rate']} | {rv['tag_rate']} | {rs['masked']['tag_rate']} "
    f"| {ref['memorisation_gap_public_minus_masked']} |\n"
    f"| 背题者（直接读公开答案表答题） | {mv['exact_rate']} | **{ms['masked']['exact_rate']}** "
    f"| {ms['hidden']['exact_rate']} | {mv['tag_rate']} | **{ms['masked']['tag_rate']}** "
    f"| **{mem['memorisation_gap_public_minus_masked']}** |\n\n"
    f"（上表数字来自 `evidence/score_reference.log` 与 `evidence/score_memoriser.log`，可对着日志重跑核对。）\n\n"
    f"背题者在公开列满分、抹名后结论掉到 {ms['masked']['exact_rate']}、理由掉到 {ms['masked']['tag_rate']} "
    "—— 抹名那一列真的会抓人，而且理由列比结论列掉得更狠。\n\n"
    f"**旧稿的两个数已作废**：早先文档写的\"参考 1.0 / 背题者 masked 0.094\"是在旧掩码规则与旧题集状态下得到的，"
    "现版本重跑为 "
    f"{rv['exact_rate']} 与 {ms['masked']['exact_rate']}。本台以 `evidence/` 里那份原始输出为准，"
    "不以任何一处转述为准。\n\n"
    f"**空基线**：一律判 'go' 的精确匹配 {bl['public']['exact_rate']}、宏召回 {bl['public']['macro_recall']}"
    "（宏召回只对本台出现过的类别取平均，本台 reject 为 0，所以是 1/2）。每次跑分都会打出这一行——"
    "让头条数字看起来强的集合等于没测。\n\n"
)
readme = readme[:old_table_start] + new_block + readme[old_table_end:]

# 追加两节：证据、隐藏题承诺怎么验
if "## 证据在哪" not in readme:
    readme += f"""
## 证据在哪

包里 `evidence/` 放的是分数背后的原始输出：

| 文件 | 内容 |
|---|---|
| `evidence/score_reference.log` | 参考裁判本版一次运行（{rv['exact_rate']} / {rs['masked']['exact_rate']} / {rs['hidden']['exact_rate']}） |
| `evidence/score_memoriser.log` | 背题者同次运行（{mv['exact_rate']} → {ms['masked']['exact_rate']}） |
| `evidence/commit_check.log` | 10 条隐藏题承诺核对 |
| `evidence/scores/*.json` | 逐题行；`python bench.py --verify <文件>` 可复算 |

## 隐藏题承诺怎么验（外人可做）

```
python bench.py --commit-check          # 列出 10 条承诺；本包里没有隐藏题，故只校验存在性
```

隐藏题字节不在本包里，所以这里只能说"承诺在"；想真正以字节撞哈希，需要隐藏题在我们手里跑完把成绩交回。
这是设计上的取舍：**隐藏题一旦能验字节，就等于泄露了题**。承诺文件 `hidden_commitment.json` 里每题只留 `case_id + sha256(salt||case)`。
"""
(B / "README.md").write_text(readme, encoding="utf-8")

# 数据卡：基线数字与 masked 数字
card = (B / "DATASET_CARD.md").read_text(encoding="utf-8")
card = card.replace("`exact_rate` 会被\"全押 go\"骗到 **0.875**，而它的 `macro_recall` 只有 **0.3333**",
                    f"`exact_rate` 会被\"全押 go\"骗到 **{bl['public']['exact_rate']}**，而它的 `macro_recall` 只有 "
                    f"**{bl['public']['macro_recall']}**（本台 reject 为 0，宏平均只在本台出现过的类别上算，故为 1/2）")
card = card.replace("背题者 public 1.0 → masked **0.0938**，参考实现 1.0 → 1.0",
                    f"背题者 public {mv['exact_rate']} → masked **{ms['masked']['exact_rate']}**，"
                    f"参考实现 {rv['exact_rate']} → {rs['masked']['exact_rate']}")
if "## 11. 证据与可追性" not in card:
    card += f"""
## 11. 证据与可追性（{ref['verdict_sha12'][:12]} / {mem['verdict_sha12'][:12]}）

本卡所有分数都指向 `evidence/` 里的原始输出，不指向任何转述：

| 说法 | 证据文件 | 实测值 |
|---|---|---|
| 参考裁判的分数 | `evidence/score_reference.log` | public {rv['exact_rate']}、masked {rs['masked']['exact_rate']}、hidden {rs['hidden']['exact_rate']}、tag {rv['tag_rate']} |
| 背题者会现形 | `evidence/score_memoriser.log` | public {mv['exact_rate']} → masked {ms['masked']['exact_rate']}、tag {mv['tag_rate']} → {ms['masked']['tag_rate']} |
| 隐藏题承诺存在 | `evidence/commit_check.log` | 10 条，`PASS` |
| 空基线 | 每次跑分打印的 `baseline` 行 | exact {bl['public']['exact_rate']}、macro_recall {bl['public']['macro_recall']} |

早先文档曾写"参考 1.0 / 背题者 masked 0.094"，与本版实测不符，已作废；差异源于旧掩码规则与旧题集状态。
**本卡不以自述数字为准，以 `evidence/` 的日志为准。**
"""
(B / "DATASET_CARD.md").write_text(card, encoding="utf-8")
print("README / 数据卡已对齐：ref", rv["exact_rate"], rs["masked"]["exact_rate"], rs["hidden"]["exact_rate"],
      "| mem", mv["exact_rate"], ms["masked"]["exact_rate"], "| baseline", bl["public"]["exact_rate"], bl["public"]["macro_recall"])
