VERDICTS = ("go", "reject", "hold")
TAGS = ("ok_covered", "outside_scope", "acceptance_not_met",
        "evidence_missing", "intended_use_change", "unclassifiable")


def evaluate(ctx):
    """Read the change facts; return one verdict AND the reason, in the
    bench vocabulary. A verdict without a reason is refused."""
    return {"verdict": "hold", "tag": "unclassifiable"}
