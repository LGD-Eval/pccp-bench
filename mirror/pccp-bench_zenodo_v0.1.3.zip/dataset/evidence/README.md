# evidence/ — 我们说的数，对应的原始输出

包里每个分数都应该能追到一次真实运行。这里放的就是那几次运行：

| 文件 | 是什么 | 怎么复现 |
|---|---|---|
| `score_reference.log` | 参考裁判一次完整运行（public 0.9688 / masked 0.9688 / tag 1.0） | `python bench.py --submit adapter_reference.py --team reference` |
| `score_memoriser.log` | 背题者（直接读公开答案表）同一次运行（public 1.0 → masked 0.094、tag 0.031） | `python bench.py --submit adapter_memoriser_for_test.py` |
| `commit_check.log` | 10 条隐藏题承诺的核对输出 | `python bench.py --commit-check` |
| `scores/*.json` | 上面两次运行落下的成绩文件（逐题行 + 摘要） | `python bench.py --verify scores/<file>` |

两个数要一起看：**参考 1.0→1.0，背题者 1.0→0.094**。masked 列不是难度分，是泄漏探针 ——
它低，说明这个判定器在靠编号记答案；它高，才说明它读的是事实。

`INDEX.json` 给每份日志与成绩文件的 sha256，改一个字节就会和这里对不上。

这些日志是**发布时刻的那一次运行**，不随你重跑而更新；你重跑得到的输出应当与它一致（时间戳行除外）。

## 外人能不能复算这两份成绩（一条实诚的限制）

`evidence/scores/*.json` 的摘要把**隐藏题**也算进去了（作者环境有隐藏集，外人没有）。
所以外人拿本包跑 `python bench.py --verify evidence/scores/score_reference_ours__*.json` 会得到
`REFUSE: digest ... != claimed ...` —— **这是预期行为，不是包坏了**。

外人能复算的是公开列那些数：重跑 `--submit adapter_reference.py` 应得 `public=0.9688 / masked=0.9688 / tag=1.0/1.0`，
与本日志逐字相同（时间戳行除外）。隐藏列的 0.9 只有在我们这里、用隐藏题跑才有，属于"承诺 + 事后交付"那一侧。

这条限制写在包里而不是留在口头：一份说自己"哪里不能被外人验证"的交付，比一份处处都说"已验证"的交付可信。
