"""PCCP-Bench v0 -- score a change-scope judge on the same questions, same ruler.

The point of a bench is that a stranger can put their judge on the stand and
get a number, and that the number can be recomputed by anyone from the score
file plus the case set. So:

  * the runner knows nothing about our engine: it imports YOUR adapter, which
    exposes evaluate(ctx) -> {"verdict": "go" | "reject" | "hold", ...}
  * three columns, and the middle one is the honesty check:
        public  -- the cases everyone can see (memorising helps here)
        masked  -- the same cases with identifiers stripped (memorising dies)
        hidden  -- held-out cases, never published, scored here and only here
  * a score file carries a digest over the case set + the verdicts. --verify
    recomputes it and refuses when the printed number is typed rather than run.

This is a bench skeleton, not a ranking: 8 real cases. See README.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
PUBLIC = os.path.join(HERE, "cases_public.json")
HIDDEN = os.path.join(HERE, "hidden", "hidden_cases.json")
COMMIT = os.path.join(HERE, "hidden_commitment.json")
VERDICTS = ("go", "reject", "hold")
# Bench-owned reason vocabulary. Our engine's rule ids are ours; a stranger's
# judge has different ones. So both are asked the same six words instead.
TAGS = ("ok_covered", "outside_scope", "acceptance_not_met",
        "evidence_missing", "intended_use_change", "unclassifiable")
# Strip the things a memoriser can key on: submission numbers, device and
# company names. A judge that reads the facts should not notice.
MASK_PATTERNS = [r"\bK\d{6}\b", r"\bDEN\d{6}\b", r"\bP\d{6}\b", r"\bv\d+(\.\d+)*\b"]


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def mask_case(case: dict) -> dict:
    text = json.dumps(case, ensure_ascii=False)
    for pat in MASK_PATTERNS:
        text = re.sub(pat, "X-CASE", text)
    return json.loads(text)


def load_adapter(path: str):
    spec = importlib.util.spec_from_file_location("submission_adapter", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "evaluate"):
        raise SystemExit("adapter has no evaluate(ctx) -- see bench_template.py")
    return mod


def ask(adapter, case: dict) -> tuple[str, str]:
    """Return (verdict, tag). The tag is mandatory: a judge that reaches the right
    word by luck still has to say why, in the bench's own vocabulary."""
    res = adapter.evaluate(dict(case)) or {}
    v = res.get("verdict")
    if v not in VERDICTS:
        raise SystemExit(f"adapter returned an unknown verdict {v!r} for {case.get('case_id')}")
    tag = res.get("tag")
    if tag not in TAGS:
        raise SystemExit(f"adapter returned an unknown tag {tag!r} for {case.get('case_id')} "
                         f"-- allowed: {TAGS}")
    return v, tag


def score_rows(rows: list[dict]) -> dict:
    n = len(rows)
    ok = sum(1 for r in rows if r["expected"] == r["actual"])
    per = {v: {"n": 0, "ok": 0} for v in VERDICTS}
    for r in rows:
        per[r["expected"]]["n"] += 1
        per[r["expected"]]["ok"] += int(r["expected"] == r["actual"])
    recalls = [per[v]["ok"] / per[v]["n"] for v in VERDICTS if per[v]["n"]]
    tag_ok = sum(1 for r in rows if r.get("expected_tag") == r.get("tag"))
    tag_per = {t: {"n": 0, "ok": 0} for t in TAGS}
    for r in rows:
        et = r.get("expected_tag")
        if et in tag_per:
            tag_per[et]["n"] += 1
            tag_per[et]["ok"] += int(et == r.get("tag"))
    tag_recalls = [tag_per[t]["ok"] / tag_per[t]["n"] for t in TAGS if tag_per[t]["n"]]
    return {"n": n, "exact": ok, "exact_rate": round(ok / n, 4) if n else 0.0,
            # Which cases were missed, by name. A bare rate hides whether a
            # shortfall is one principled disagreement or scattered noise.
            "misses": [r["case_id"] for r in rows if r.get("case_id")
                       and r["expected"] != r["actual"]],
            "macro_recall": round(sum(recalls) / len(recalls), 4) if recalls else 0.0,
            "per_class": per,
            "tag_exact": tag_ok, "tag_rate": round(tag_ok / n, 4) if n else 0.0,
            "tag_macro_recall": round(sum(tag_recalls) / len(tag_recalls), 4) if tag_recalls else 0.0,
            "tag_per_class": tag_per}


def digest(cases_public: list, cases_hidden: list, cols: dict) -> str:
    """Digest over the questions and the answers -- never over timings, paths or
    host facts, so the same run on another machine yields the same string."""
    seed = json.dumps({"public": [[c["case_id"], c["expected_verdict"]] for c in cases_public],
                       "hidden": [[c["case_id"], c["expected_verdict"]] for c in cases_hidden],
                       "answers": cols}, ensure_ascii=False, sort_keys=True)
    return sha256_text(seed)


def run(adapter_path: str, team: str) -> dict:
    adapter = load_adapter(adapter_path)
    pub = json.load(open(PUBLIC, encoding="utf-8"))["cases"]
    # The public bundle ships without the held-out set. Running there is a
    # self-check on two columns, never a score: the hidden column is where a
    # submission gets measured, and that happens on our side.
    hid = json.load(open(HIDDEN, encoding="utf-8"))["cases"] if os.path.exists(HIDDEN) else []
    scored_hidden = bool(hid)

    cols = {"public": [], "masked": [], "hidden": []}
    for c in pub:
        v, t = ask(adapter, c)
        cols["public"].append({"case_id": c["case_id"], "expected": c["expected_verdict"],
                               "actual": v, "expected_tag": c["expected_tag"], "tag": t})
    for c in pub:
        m = mask_case(c)
        v, t = ask(adapter, m)
        cols["masked"].append({"case_id": m["case_id"], "expected": c["expected_verdict"],
                               "actual": v, "expected_tag": c["expected_tag"], "tag": t})
    for c in hid:
        v, t = ask(adapter, c)
        cols["hidden"].append({"case_id": c["case_id"], "expected": c["expected_verdict"],
                               "actual": v, "expected_tag": c["expected_tag"], "tag": t})

    s = {k: score_rows(v) for k, v in cols.items()}
    gap = round(s["public"]["exact_rate"] - s["masked"]["exact_rate"], 4)

    # A dummy that answers "go" to everything, scored by the same code path.
    # Published next to every submission, because 37 of 42 labels are "go": a
    # reader who only looks at exact_rate cannot tell a judge from that dummy.
    dummy = {k: score_rows([{"expected": r["expected"], "actual": "go",
                             "expected_tag": r["expected_tag"], "tag": "ok_covered"} for r in v])
             for k, v in cols.items()}
    payload = {
        "bench": "PCCP-Bench v1",
        "team": team,
        "adapter_file": os.path.basename(adapter_path),
        "adapter_sha256": sha256_text(open(adapter_path, encoding="utf-8").read()),
        "score": s,
        "baseline_always_go": dummy,
        "hidden_scored": scored_hidden,
        "public_bundle": not scored_hidden,
        "memorisation_gap_public_minus_masked": gap,
        "tag_gap_public_minus_masked": round(s["public"]["tag_rate"] - s["masked"]["tag_rate"], 4),
        "claim": "作者自评，未经第三方复核；42 例是骨架不是榜",
        "verdict_sha12": digest(pub, hid, cols)[:12],
        "full_digest": digest(pub, hid, cols),
        "_rows": cols,
    }
    return payload


def main() -> int:
    os.makedirs(OUT, exist_ok=True)
    argv = sys.argv[1:]
    if "--template" in argv:
        open(os.path.join(HERE, "bench_template.py"), "w", encoding="utf-8").write(
            'VERDICTS = ("go", "reject", "hold")\n'
            'TAGS = ("ok_covered", "outside_scope", "acceptance_not_met",\n'
            '        "evidence_missing", "intended_use_change", "unclassifiable")\n\n\n'
            'def evaluate(ctx):\n'
            '    """Read the change facts; return one verdict AND the reason, in the\n'
            '    bench vocabulary. A verdict without a reason is refused."""\n'
            '    return {"verdict": "hold", "tag": "unclassifiable"}\n')
        print("wrote bench_template.py")
        return 0
    if "--submit" in argv:
        path = argv[argv.index("--submit") + 1]
        team = argv[argv.index("--team") + 1] if "--team" in argv else "anonymous"
        res = run(path, team)
        digest12 = res["verdict_sha12"]
        name = re.sub(r"[^A-Za-z0-9_-]+", "_", team)[:40] or "anonymous"
        out = os.path.join(OUT, f"score_{name}_{digest12}.json")
        json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        hscore = (f"{res['score']['hidden']['exact_rate']}" if res["hidden_scored"]
                  else "n/a (public bundle)")
        htag = (f"{res['score']['hidden']['tag_rate']}" if res["hidden_scored"] else "n/a")
        print(f"{team}: exact public={res['score']['public']['exact_rate']} "
              f"masked={res['score']['masked']['exact_rate']} "
              f"hidden={hscore} "
              f"tag={res['score']['public']['tag_rate']}/"
              f"{res['score']['masked']['tag_rate']}/"
              f"{htag} "
              f"gap={res['memorisation_gap_public_minus_masked']} sha={digest12}")
        bl = res["baseline_always_go"]
        print(f"  macro_recall(verdict) public={res['score']['public']['macro_recall']} "
              f"masked={res['score']['masked']['macro_recall']} "
              f"tag={res['score']['public']['tag_macro_recall']}/"
              f"{res['score']['masked']['tag_macro_recall']}")
        print(f"  baseline: always-'go' scores exact={bl['public']['exact_rate']} "
              f"but macro_recall={bl['public']['macro_recall']} -- exact alone is not a result.")
        # Verdict mix, printed before the reader gets to feel good about the
        # number: an 88%-"go" set makes a high exact rate partly the base rate.
        # A footnote in the datasheet is not where this belongs.
        mix = {}
        for c in json.load(open(PUBLIC, encoding="utf-8"))["cases"]:
            k = c.get("expected_verdict", "?")
            mix[k] = mix.get(k, 0) + 1
        print("  mix(public): " + ", ".join(f"{k}={mix.get(k, 0)}" for k in VERDICTS)
              + f" of {sum(mix.values())} -- skewed by design; read exact rate as base rate + skill.")
        if not res["hidden_scored"]:
            print("note: this bundle has no held-out set -- a self-check on two columns, "
                  "not a score. Send the adapter to us for the third column.")
        # A submitted adapter is scored, not graded pass/fail: exit non-zero only
        # when the adapter itself is unusable. Judging whether 0.9688 is good is
        # the reader's business, and the baseline line above is there to tell them.
        return 0
    if "--verify" in argv:
        path = argv[argv.index("--verify") + 1]
        doc = json.load(open(path, encoding="utf-8"))
        cols = doc.pop("_rows", None)
        if not cols:
            print("REFUSE: score file carries no per-case rows -- nothing to recompute")
            return 3
        pub = json.load(open(PUBLIC, encoding="utf-8"))["cases"]
        hid = json.load(open(HIDDEN, encoding="utf-8"))["cases"] if os.path.exists(HIDDEN) else []
        recomputed = {k: score_rows(v) for k, v in cols.items()}
        if recomputed != doc["score"]:
            print("REFUSE: printed scores do not match the rows -- numbers were typed")
            return 3
        d12 = digest(pub, hid, cols)[:12]
        if d12 != doc["verdict_sha12"]:
            print(f"REFUSE: digest {d12} != claimed {doc['verdict_sha12']}")
            return 3
        print(f"VERIFIED: {d12} scores recomputed from rows")
        return 0
    if "--commit-check" in argv:
        commit = json.load(open(COMMIT, encoding="utf-8"))
        # The public bundle ships the commitment but not the held-out cases. In
        # that case there is nothing here to hash against, and saying so is the
        # honest answer -- the earlier version crashed instead.
        if not os.path.exists(HIDDEN):
            ids = [c.get("case_id") for c in commit.get("cases", [])]
            ok = len(ids) == 10 and all(isinstance(i, str) and i for i in ids)
            print(f"COMMIT: {len(ids)} commitments present, bytes not verifiable here "
                  f"(held-out set is not in this bundle) -- {'PASS' if ok else 'FAIL'}")
            return 0 if ok else 1
        hid = json.load(open(HIDDEN, encoding="utf-8"))["cases"]
        bad = [c["case_id"] for c in commit["cases"]
               if sha256_text(commit["salt"] + c["case_id"] +
                              json.dumps(next(x for x in hid if x["case_id"] == c["case_id"]),
                                         ensure_ascii=False, sort_keys=True)) != c["sha256"]]
        print("COMMIT: " + ("PASS" if not bad else f"FAIL {bad}"))
        return 0 if not bad else 1
    print(__doc__)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
