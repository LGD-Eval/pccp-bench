#!/bin/sh
# One-double-click entry for macOS / Linux. ASCII only, so it survives any locale.
cd "$(dirname "$0")" || exit 2
echo "============================================================"
echo "  PCCP-Bench public self-check"
echo "  This is NOT a score. There is no held-out set in this bundle."
echo "============================================================"
echo ""

PY=""
if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else
  echo "[STOP] No python3 / python on PATH. Install Python 3.9+ and retry."
  exit 2
fi
"$PY" --version || exit 2
echo ""
echo "[1/2] bundle integrity: hidden commitment vs shipped bytes"
"$PY" bench.py --commit-check
echo ""
echo "[2/2] run the demo adapter through the scorer"
echo "      The demo answers hold to everything, so a low number is expected."
echo "      Replace bench_template.py with your own judge to see yours."
"$PY" bench.py --submit bench_template.py --team selfcheck-demo
echo ""
echo "------------------------------------------------------------"
echo "Done. Copy this output back as-is, success or error."
echo "------------------------------------------------------------"
